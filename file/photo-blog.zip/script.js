const generateBtn = document.querySelector('#generateBtn');
const gridContainer = document.querySelector('#gridContainer');

generateBtn.addEventListener('click', () => {
    
    //Delete all images if there are more than 30 images
     if(gridContainer.children.length >= 30) {
        const confirmed = confirm("You have 30 images. Are you sure you want to delete all images?");
        if(confirmed) {
            gridContainer.innerHTML = ""; // delete all images
        } 
    } else {
        const randomNumber = Math.floor(Math.random() * 1000) + 1;
        const imgUrl = `https://picsum.photos/500?random=${randomNumber}`;
    
        const img = document.createElement('img');
        img.src = imgUrl;
        //img.src = `https://picsum.photos/500?random=${Math.floor(Math.random() * 1000) + 1}`;
        //console.log(Math.floor(Math.random() * 1000) + 1);
    
        gridContainer.appendChild(img);   
    }  
});
